package com.dao;

public interface IRoleDao {
}
