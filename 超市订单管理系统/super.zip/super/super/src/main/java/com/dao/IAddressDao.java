package com.dao;

public interface IAddressDao {
}
